# MinoSim Theme
Theme + plugin website bán sim sử dụng mà nguồn wordpress
## Update ngày 09/08/2019
- Thêm đầu số 052
- Fix lỗi sim không xác định
- Sửa giao diện với sim giá lớn (vài tỷ)

## Update ngày 08/08/2019
- Đơn hàng có tên đại lý  (order_agency_id, order_agency_name)
- Cải thiện tìm sim admin: bỏ dấu chấm, ký tự đặc biệt vẫn tìm được sim
- Ảnh có loại sim và giá
- Đổi order_time = order_code
